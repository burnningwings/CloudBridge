<script>
import axios from "axios"
import {BRIDGE_IMGURL_MAPPING, B} from "../../config/config.js"
export default {
  // declare emitted events
  emits: ['response'],

  data(){
    return {
      options_bridge: [],
      options_section: [],
      options_point: [],
      options_box: [],
      options_sensor: [],
      selected_bridge: "全部桥梁",  //  默认值, 对应的id为0
      selected_section: "全部截面", //  默认值, 对应的id为0
      selected_point: "全部测点", //  默认值, 对应的id为0
      selected_box: "全部模块", //  默认值, 对应的id为0
      selected_sensor: "请选择传感器",
      current_bridgeID_map: {},   // name到id的映射
      current_sectionID_map: {},   // name到id的映射
      current_pointID_map: {},   // name到id的映射
      current_boxID_map: {},   // name到id的映射
      current_sensorID_map: {},   // name到id、sensor_type_name、sensor_type_id的映射
      bridge_img_url: "",
      time_value: [],
      begin_time: "",
      end_time: "",
      loading: false,
    }
  },

  mounted() {
    this.getBridgeMessage()
    this.getSensorMessage(0, 0, 0, 0)
    console.log("import BRIDGE_IMG_MAPPING from \"../../config/config.js\"")
    console.log(BRIDGE_IMGURL_MAPPING, B)
    // console.log(this.options_bridge)
    // console.log(a)
  },

  methods:{
    processInfo(info, type) {
      /**
       * 处理后端返回桥梁、截面、控制箱（模块）、监测点数据, 更新响应式对象数据
       * 名字和id需要一一对应，即不可同名，否则无法区分
       * **/
      if (type!=="bridge" && type!=="section" && type!=="watch_box" && type!=="watch_point"){
        alert("can't accept this type: " + type)
        return
      }
      info = info["data"]
      let name_key = type + "_name"
      let id_key = type + "_id"
      let options_arr = []
      let id_dict = {}
      for (let i=0;i<info.length;i++){
        let name = info[i][name_key]
        let id =  info[i][id_key]
        // TODO: 目前只处理肇庆西江大桥和阅江大桥
        // if (type==="bridge" && name.indexOf("西江")===-1 && name.indexOf("阅江")===-1)
        //   continue;
        let option = {value: name, label: name}
        id_dict[name] = id
        options_arr.push(option)
      }
      if (type === "bridge"){
        let option = {value: "全部桥梁", label: "全部桥梁"}
        options_arr.push(option)
        id_dict["全部桥梁"] = 0
        this.options_bridge = options_arr
        this.current_bridgeID_map = id_dict
        // console.log("options_bridge: ", this.options_bridge)
        // console.log("current_bridgeID_map: ", this.current_bridgeID_map)
      }
      else if (type === "section"){
        let option = {value: "全部截面", label: "全部截面"}
        options_arr.push(option)
        id_dict["全部截面"] = 0
        this.options_section = options_arr
        this.current_sectionID_map = id_dict
        // console.log("options_section: ", this.options_section)
        // console.log("current_sectionID_map: ", this.current_sectionID_map)
      }
      else if (type === "watch_box"){
        let option = {value: "全部模块", label: "全部模块"}
        options_arr.push(option)
        id_dict["全部模块"] = 0
        this.options_box = options_arr
        this.current_boxID_map = id_dict
        // console.log("options_section: ", this.options_box)
        // console.log("current_sectionID_map: ", this.current_boxID_map)
      }
      else {
        let option = {value: "全部监测点", label: "全部监测点"}
        options_arr.push(option)
        id_dict["全部监测点"] = 0
        this.options_point = options_arr
        this.current_pointID_map = id_dict
        // console.log("options_point: ", this.options_point)
        // console.log("current_pointID_map: ", this.current_pointID_map)
      }
    },

    processSensorInfo(info){
      /** 处理后端传感器接口返回的数据, 更新响应式数据 **/
      info = info["data"]["data"]
      let options_arr = []
      let id_dict = {}
      for (let i=0;i<info.length;i++){
        let sensor_name = info[i]["sensor_name"]
        let sensor_id =  info[i]["sensor_id"]
        let sensor_type_name = info[i]["sensor_type_name"]
        let sensor_type_id = info[i]["sensor_type_id"]
        sensor_name += "-" + sensor_type_name
        // console.log(sensor_name, sensor_id, sensor_type_name, sensor_type_id)
        let option = {value: sensor_name, label: sensor_name}
        id_dict[sensor_name] = {sensor_id: sensor_id, sensor_type_name: sensor_type_name, sensor_type_id: sensor_type_id}
        options_arr.push(option)
      }
      this.options_sensor = options_arr
      this.current_sensorID_map = id_dict
      // console.log("options_sensor: ", this.options_sensor)
      // console.log("current_sensorID_map: ", this.current_sensorID_map)
    },

    getBridgeMessage(){
      // axios get bridge information from API
      // this.options_bridge = [{value: "阅江大桥", name: "yuejiang"}, {value: "肇庆西江大桥", name: "xijiang"}]
      // console.log("in getBridgeMessage()")
      axios.get("/bridge/simple-list")
          .then(res => {
            console.log("axios got results from /bridge/simple-list in [BridgeSelector]: ", res)
            if(res["status"]===200 && res != null)
              this.processInfo(res["data"], "bridge")
          }).catch(err =>{
            console.log("error: ", err)
      })
      // console.log("axios finished getBridgeMessage()!")
    },

    getSectionMessage(bridge_id){
      let params = {bridgeId: bridge_id}
      // console.log("in getSectionMessage()")
      axios.get("/section/simple-list", {params: params})
          .then(res => {
            console.log("axios got results from /section/simple-list in [BridgeSelector]: ", res)
            if(res["status"]===200 && res != null)
              this.processInfo(res["data"], "section")
          }).catch(err =>{
        console.log("error: ", err)
      })
      // console.log("axios finished getSectionMessage()!")
    },

    getBoxMessage(bridge_id){
      let params = {bridgeId: bridge_id}
      // console.log("in getBoxMessage()")
      axios.get("/watch-box/simple-list", {params: params})
          .then(res => {
            console.log("axios got results from /watch-box/simple-list in [BridgeSelector]: ", res)
            if(res["status"]===200 && res != null)
              this.processInfo(res["data"], "watch_box")
          }).catch(err =>{
        console.log("error: ", err)
      })
      // console.log("axios finished getBoxMessage()!")
    },

    getPointMessage(section_id){
      let params = {sectionId: section_id}
      // console.log("in getPointMessage()")
      axios.get("/watch-point/simple-list", {params: params})
          .then(res => {
            console.log("axios got results from /watch-point/simple-list in [BridgeSelector]: ", res)
            if(res["status"]===200 && res != null)
              this.processInfo(res["data"], "watch_point")
          }).catch(err =>{
        console.log("error: ", err)
      })
      // console.log("axios finished getPointMessage()!")
    },

    getSensorMessage(bridge_id=0, section_id=0, watch_box_id=0, watch_point_id=0){
      let params = {bridgeId: bridge_id, sectionId: section_id, watchPointId: watch_point_id, watchBoxId: watch_box_id,
                    page: 1, pageSize: 9223372036854770}
      // console.log("to sensor API: ", params)
      axios.get("/sensor/list", {params: params})
          .then(res => {
            console.log("axios got results from /sensor/list in [BridgeSelector]: ", res)
            if(res["status"]===200 && res != null)
              this.processSensorInfo(res)
          }).catch(err =>{
        console.log("error: ", err)
      })
      // console.log("axios finished getSensorMessage()!")
    },

    handleChangeBridge(){
      // console.log("Bridge changed to: " + this.selected_bridge)
      // 重置所有其他选项数据
      this.selected_section = "全部截面"
      this.options_section = []
      this.current_sectionID_map = {}
      this.selected_point = "全部测点"
      this.options_point = []
      this.current_pointID_map = {}
      this.selected_box = "全部模块"
      this.options_box = []
      this.current_boxID_map = {}
      this.selected_sensor = "请选择传感器"
      this.options_sensor = []
      this.current_sensorID_map = {}

      let current_bridge_id = this.current_bridgeID_map[this.selected_bridge]
      if(BRIDGE_IMGURL_MAPPING.hasOwnProperty(current_bridge_id))
        this.bridge_img_url = BRIDGE_IMGURL_MAPPING[current_bridge_id]
      else
        this.bridge_img_url = ""
      // 根据bridge_id请求得到截面、控制箱、传感器的数据
      // section/simple-list?bridgeId={x}
      // watch-box/simple-list?bridgeId={x}

      this.getSectionMessage(current_bridge_id)
      this.getBoxMessage(current_bridge_id)
      this.getSensorMessage(current_bridge_id, 0, 0, 0)
    },

    handleChangeSection() {
      // console.log("Section changed to: " + this.selected_section)
      // 重置测点和传感器数据
      this.selected_point = "全部测点"
      this.options_point = []
      this.current_pointID_map = {}
      this.selected_sensor = "请选择传感器"
      this.options_sensor = []
      this.current_sensorID_map = {}
      // TODO:控制箱和(截面、测点)这两个不能一起选???
      // this.selected_box = "全部模块"

      // 根据截面获取监测点信息
      // watch-point/simple-list?sectionId={x}
      let current_section_id = this.current_sectionID_map[this.selected_section]
      this.getPointMessage(current_section_id)

      // 根据桥梁id、截面id、模块id获取传感器信息
      let current_bridge_id = this.current_bridgeID_map[this.selected_bridge]
      let current_box_id = this.current_boxID_map[this.selected_box]
      // if(this.current_boxID_map.hasOwnProperty(this.selected_box))
      this.getSensorMessage(current_bridge_id, current_section_id, current_box_id, 0)
    },

    handleChangeBox(){
      // console.log("Watch Box changed to: " + this.selected_box)
      // 重置传感器数据
      this.selected_sensor = "请选择传感器"
      this.options_sensor = []
      this.current_sensorID_map = {}
      // TODO：控制箱和(截面、测点)这两个不能一起选？？？
      // this.selected_section = "全部截面"
      // this.selected_point = "全部测点"

      // 根据桥梁id、截面id、模块id获取传感器信息
      // sensor/list?page=1&pageSize=9223372036854770&bridgeId={a}&sectionId={b}&watchPointId={c}&watchBoxId={d}
      let current_box_id = this.current_boxID_map[this.selected_box]
      let current_bridge_id = this.current_bridgeID_map[this.selected_bridge]
      let current_section_id = this.current_sectionID_map[this.selected_section]
      // if(this.current_sectionID_map.hasOwnProperty(this.selected))
      this.getSensorMessage(current_bridge_id, current_section_id, current_box_id, 0)
    },

    handleChangeSensor(){
      // console.log("Sensor changed to: " + this.selected_sensor)
    },

    onDateChange(value, dateString){
      // console.log("selected time: ", value);
      // console.log("Formatted selected time: ", dateString)
      this.begin_time = dateString[0]
      this.end_time = dateString[1]
    },

    handleMonitoringButtonClick() {
      // alert("你点击了'开始实时监控'按钮")
      console.log("*************************************")
      console.log("Click the button, 开始实时监控")
      console.log("begin_time: ", this.begin_time)
      console.log("end_time: ", this.end_time)

      let bridge_id = 0
      if(this.current_bridgeID_map.hasOwnProperty(this.selected_bridge))
        bridge_id = this.current_bridgeID_map[this.selected_bridge]

      let section_id = 0
      if(this.current_sectionID_map.hasOwnProperty(this.selected_section))
        section_id = this.current_sectionID_map[this.selected_section]

      let box_id = 0
      if(this.current_boxID_map.hasOwnProperty(this.selected_box))
        box_id = this.current_boxID_map[this.selected_box]

      let sensor_info = {}
      if(this.current_sensorID_map.hasOwnProperty(this.selected_sensor))
        sensor_info = this.current_sensorID_map[this.selected_sensor]
      console.log("bridge: ", this.selected_bridge, bridge_id)
      console.log("section: ", this.selected_section, section_id)
      console.log("box：", this.selected_box, box_id)
      console.log("sensor: ", this.selected_sensor, sensor_info)
      console.log("*************************************")
      let res = [0, bridge_id, section_id, box_id, sensor_info, this.begin_time, this.end_time]
      this.$emit('response', res)
      // console.log("[BridgeSelector]emitted params to father [MonitoringHall]")
    },

    handleReliabilityButtonClick(){
      // alert("你点击了'开始可靠性分析'按钮")
      console.log("*************************************")
      console.log("Click the button, 开始可靠性分析")
      console.log("begin_time: ", this.begin_time)
      console.log("end_time: ", this.end_time)

      let bridge_id = 0
      if(this.current_bridgeID_map.hasOwnProperty(this.selected_bridge))
        bridge_id = this.current_bridgeID_map[this.selected_bridge]

      let section_id = 0
      if(this.current_sectionID_map.hasOwnProperty(this.selected_section))
        section_id = this.current_sectionID_map[this.selected_section]

      let box_id = 0
      if(this.current_boxID_map.hasOwnProperty(this.selected_box))
        box_id = this.current_boxID_map[this.selected_box]

      let sensor_info = {}
      if(this.current_sensorID_map.hasOwnProperty(this.selected_sensor))
        sensor_info = this.current_sensorID_map[this.selected_sensor]
      console.log("bridge: ", this.selected_bridge, bridge_id)
      console.log("section: ", this.selected_section, section_id)
      console.log("box：", this.selected_box, box_id)
      console.log("sensor: ", this.selected_sensor, sensor_info)
      console.log("*************************************")
      let res = [1, bridge_id, section_id, box_id, sensor_info, this.begin_time, this.end_time]
      this.$emit('response', res)
      // console.log("[BridgeSelector]emitted params to father [MonitoringHall]")
    },

    handleAssociationButtonClick(){
      // alert("你点击了'开始关联性分析'按钮")
      console.log("*************************************")
      console.log("Click the button, 开始关联性分析")
      console.log("begin_time: ", this.begin_time)
      console.log("end_time: ", this.end_time)

      let bridge_id = 0
      if(this.current_bridgeID_map.hasOwnProperty(this.selected_bridge))
        bridge_id = this.current_bridgeID_map[this.selected_bridge]

      let section_id = 0
      if(this.current_sectionID_map.hasOwnProperty(this.selected_section))
        section_id = this.current_sectionID_map[this.selected_section]

      let box_id = 0
      if(this.current_boxID_map.hasOwnProperty(this.selected_box))
        box_id = this.current_boxID_map[this.selected_box]

      let sensor_info = {}
      if(this.current_sensorID_map.hasOwnProperty(this.selected_sensor))
        sensor_info = this.current_sensorID_map[this.selected_sensor]
      console.log("bridge: ", this.selected_bridge, bridge_id)
      console.log("section: ", this.selected_section, section_id)
      console.log("box：", this.selected_box, box_id)
      console.log("sensor: ", this.selected_sensor, sensor_info)
      console.log("*************************************")
      let res = [2, bridge_id, section_id, box_id, sensor_info, this.begin_time, this.end_time]
      this.$emit('response', res)
      // console.log("[BridgeSelector]emitted params to father [MonitoringHall]")
    }

  },

}
</script>

<template>
  <!-- 上方桥梁选择 -->
  <div style="height:6rem">
    <a-card title="桥梁选择" style="height: 100%;">
      <!--    <template #extra><a href="#">more</a></template>-->
      <img :src=this.bridge_img_url style="height: 4rem;width: 100%">
      <h1 style="margin: 0;color: white;font-size: 16px">请选择桥梁:</h1>
      <a-select
          v-model:value="selected_bridge"
          style="width: 60%"
          :options="this.options_bridge"
          @change="handleChangeBridge"
      ></a-select>
    </a-card>
  </div>

  <!-- 下方具体参数选择 -->
  <div style="height:6rem">
    <a-card title="传感器选择" style="height: 100%;">
      <p>
        桥梁截面 :
        <a-select
            v-model:value="selected_section"
            style="width: 60%"
            :options="this.options_section"
            @change="handleChangeSection"
        ></a-select>
      </p>
      <p>
        模块编号 :
        <a-select
            v-model:value="selected_box"
            style="width: 60%"
            :options="this.options_box"
            @change="handleChangeBox"
        ></a-select>
      </p>
      <p>
        传感器编号:
        <a-select
            v-model:value="selected_sensor"
            style="width: 60%"
            :options="this.options_sensor"
            @change="handleChangeSensor"
        ></a-select>
      </p>

      <!--             format="YYYY-MM-DD HH:mm:ss" -->
      <p style="margin-bottom: 0">日期选择:</p>
      <!--  v-model:value="time_value"拿到的是个moment对象的数组    -->
      <a-range-picker
          v-model:value="time_value"
          style="width: 96%"
          show-time
          format="YYYY-MM-DD HH:mm:ss"
          @change="onDateChange"
      />

      <a-button
          type="primary"
          style="margin-top: 0.3rem"
          size="large"
          :loading="this.loading"
          @click="handleMonitoringButtonClick" >
        开始实时监控
      </a-button>
      <br/>
      <a-button
          type="primary"
          style="margin-top: 0.3rem"
          size="large"
          :loading="this.loading"
          @click="handleReliabilityButtonClick" >
        开始可靠性分析
      </a-button>
      <a-divider type="vertical" style="height: 60px; border-color: white" dashed />
      <a-button
          type="primary"
          style="margin-top: 0.3rem"
          size="large"
          :loading="this.loading"
          @click="handleAssociationButtonClick" >
        开始关联性分析
      </a-button>

    </a-card>
  </div>

</template>


<style scoped lang="scss">
::v-deep .ant-card{
  background-color: #1c2031 !important;
  //background: #203bad !important;
  color: white !important;
}

::v-deep .ant-card-body{
  padding: 0;
  background-color: #1c2031 !important;
  height: 86.3%;
}

::v-deep .ant-card-head{
  color: white !important;
  background-color: #1c2031 !important;
}

::v-deep .ant-select .ant-select-selector{
  background-color: #1c2031 !important;
  color: white !important;
}
::v-deep .ant-select-arrow{
  color: white !important;
}

p{
  font-size: 16px;
}
//h1{
//  margin-bottom: 0;
//  color: white;
//  font-size: 16px;
//}
</style>