<script>
import MyMenu from "./menu.vue"
import { MenuFoldOutlined, MenuUnfoldOutlined, } from '@ant-design/icons-vue';
export default {
  components: {
    MenuFoldOutlined,
    MenuUnfoldOutlined,
    MyMenu: MyMenu
  },
  data() {
    return {
      collapsed: false
    }
  },
  methods: {
    toggleCollapsed() {
      this.collapsed = !this.collapsed
      console.log(this.collapsed)
    }
  }

}
</script>

<template>
  <a-layout-sider style="background-color: #0f1325">  <!--  v-model:collapsed="this.collapsed" collapsible -->
<!--    <a-button type="primary" style="margin-bottom: 16px" @click="this.toggleCollapsed">-->
<!--      <MenuUnfoldOutlined v-if="this.collapsed" />-->
<!--      <MenuFoldOutlined v-else />-->
<!--    </a-button>-->
    <MyMenu />
  </a-layout-sider>
</template>

<style lang="scss" scoped>
@import "../../../assets/scss/index.scss";
.menu{
  color:white;
  background-color: #0f1325;
}
</style>