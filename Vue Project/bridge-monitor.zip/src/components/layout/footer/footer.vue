<script>
export default {

}
</script>

<template>
  <!--footer-->
  <a-layout-footer style="color: white;background: rgba(15, 19, 37, 0);text-align: center;padding: 0;">
    华南理工大学 版权所有 Copyright © 2022
<!--              <img src="src/assets/scutlogo.png" style="height: 40px;width: 40px">-->
<!--              <img src="src/assets/scutlogo.png" style="height: 40px;width: 40px">-->
<!--              <img src="src/assets/scutlogo.png" style="height: 40px;width: 40px">-->
  </a-layout-footer>
</template>


<style lang="scss" scoped>
@import "../../../assets/scss/index.scss";
</style>