<script>
import MyHeader from "./header/header.vue"
import MyFooter from "./footer/footer.vue"
import MySidebar from "./sidebar/sidebar.vue"
import index from "../index/monitor-index.vue"
export default {
  components:{
    MyHeader: MyHeader,
    MyFooter: MyFooter,
    MySidebar: MySidebar,
    MyIndex: index
  },
  data() {
    return {
      loading: true
    };
  },
  mounted() {
    this.cancelLoading();
  },
  methods: {
    cancelLoading() {
      setTimeout(() => {
        this.loading = false;
      }, 1000);
    }
  }

}
</script>

<template>
  <div id="index">
    <!--
        position: fixed 时就不会有滚动条
    -->
    <dv-full-screen-container class="bg" style="height: 15rem;position: static;">
      <dv-loading v-if="loading">Loading...</dv-loading>
      <div v-else class="host-body">

        <!-- Header -->
        <MyHeader :component_parent="'DefaultLayout'"/>

        <a-layout class="rm-bg-color">
          <!-- Sidebar -->
          <MySidebar />

          <!-- Content Router -->
          <!-- 各種組件內容 -->
          <a-layout-content>
            <router-view />
          </a-layout-content>
        </a-layout>

        <!-- Footer -->
        <MyFooter />

      </div>
    </dv-full-screen-container>
  </div>
</template>

<style lang="scss">
@import "../../assets/scss/index.scss";
.component-bg{
  text-align: center;
  // 控制在框內填充背景顏色的區域
  background-color: rgba(50, 52, 65, 0.6);
  width: 100%;
  height: 100%;
  padding: 10px;
  background-clip: content-box; // 去除padding和border部分的背景颜色

}
.rm-bg-color{
  background-color:transparent !important; // 除去antd组件样式的背景颜色
}
</style>
