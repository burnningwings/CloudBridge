<script>
import selector from "./selector.vue";
export default {
  components: {
    MySelector: selector
  },
  data() {
    return {
    }
  },
  methods: {
    handleButtonClick() {
      console.log("click the a-dropdown-button")
    },
    handleMenuClick(){
      console.log("click the a-menu")
    }
  },
  mounted() {
    // console.log("aaa:\n" + aaa + "\nbbb:\n" + bbb)
  }
}
</script>

<template>

<div style="height: 12.5rem">

  <dv-border-box-12>
    <!-- 下拉选择框, 选择传感器进行展示 -->
    <MySelector />

    <div>
      <!-- 展示组件  -->
      <a-row style="margin-top: 0.1rem">
        <a-col :span="8" style="height: 300px">
          <dv-border-box-12>
            <div class="component-box-bg">
              11
            </div>
          </dv-border-box-12>
        </a-col>
        <a-col :span="8" style="height: 300px">
          <dv-border-box-12>
            <div class="component-box-bg">
              22
            </div>
          </dv-border-box-12>
        </a-col>
        <a-col :span="8" style="height: 300px">
          <dv-border-box-12>
            <div class="component-box-bg">
              33
            </div>
          </dv-border-box-12>
        </a-col>
      </a-row>
      <div style="padding-left: 0.15rem">111</div>
      <div style="padding-left: 10px">222</div>
      <div style="padding-left: 0.15rem">333</div>
    </div>

  </dv-border-box-12>

</div>
</template>




<style lang="scss" scoped>
@import "../../assets/scss/index.scss";
.component-box-bg{
  text-align: center;
  // 控制在框內填充背景顏色的區域
  background-color: rgba(50, 52, 65, 0.6);
  width: 100%;
  height: 100%;
  padding: 10px;
  background-clip: content-box; // 去除padding和border部分的背景颜色

}
</style>



<!--<template>-->
<!--  <div id="index">-->
<!--    &lt;!&ndash;  position: fixed 时就不会有滚动条-->
<!--          height属性需要在position之前定义-->
<!--          style="height: 1500px;position: static;"-->
<!--    &ndash;&gt;-->
<!--    <dv-full-screen-container class="bg" style="height: 1500px;position: static;">-->
<!--      <dv-loading v-if="loading">Loading...</dv-loading>-->
<!--      <div v-else class="host-body">-->
<!--        <a-layout>-->
<!--          &lt;!&ndash;Header&ndash;&gt;-->
<!--          <a-layout-header style="padding: 0 0">-->
<!--            &lt;!&ndash;第一行&ndash;&gt;-->
<!--            <a-row>-->
<!--              <a-col :span="6">-->
<!--                <dv-decoration-10 style="height:3px;" />-->
<!--              </a-col>-->

<!--              <a-col :span="3">-->
<!--                <dv-decoration-8 :color="['#568aea', '#000000']" style="height:30px" />-->
<!--              </a-col>-->

<!--              <a-col :span="6">-->
<!--                <div class="title">-->
<!--                  <span class="title-text" style="text-align:center; line-height:30px; color:rgb(237, 229, 215)">-->
<!--                    桥梁健康监控大厅-->
<!--                  </span>-->
<!--                  <dv-decoration-6 class="title-bototm" :reverse="true" :color="['#50e3c2', '#67a1e5']"-->
<!--                                   style="width:3.125rem;height:0.2rem;line-height: 30px;bottom: -40px;"/>-->
<!--                </div>-->
<!--              </a-col>-->

<!--              <a-col :span="3">-->
<!--                <dv-decoration-8 :reverse="true" :color="['#568aea', '#000000']" style="height:30px"/>-->
<!--              </a-col>-->

<!--              <a-col :span="6">-->
<!--                <dv-decoration-10 style="height:3px; transform: rotateY(180deg);" />-->
<!--              </a-col>-->
<!--            </a-row>-->

<!--          </a-layout-header>-->
<!--          <a-layout-content>-->
<!--            Content-->
<!--          </a-layout-content>-->
<!--          <a-layout-footer>-->
<!--            Footer-->
<!--          </a-layout-footer>-->
<!--        </a-layout>-->

<!--      </div>-->
<!--    </dv-full-screen-container>-->
<!--  </div>-->
<!--</template>-->