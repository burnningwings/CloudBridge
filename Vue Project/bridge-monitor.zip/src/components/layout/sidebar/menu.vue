<script>
import { defineComponent, reactive, toRefs } from 'vue';
import { MailOutlined, AppstoreOutlined, SettingOutlined } from '@ant-design/icons-vue';
export default defineComponent({
  components: {
    MailOutlined,
    AppstoreOutlined,
    SettingOutlined,
  },
  data(){
    return {
      rootSubmenuKeys: ['sub1', 'sub2', 'sub3'],  // 一级菜单的key
      openKeys: ['sub1'],   // 当前打开的一级菜单的key
      selectedKeys: [],
    }
  },
  watch: {
    // selectedKeys(newSelectedKeys, oldSelectedKeys) {
    //   console.log(newSelectedKeys + "\t" + oldSelectedKeys)
    // }
  },
  methods:{
    onOpenChange(openKeys) {
      if (openKeys.length === 0 || openKeys.length === 1){
        this.openKeys = openKeys;
        return;
      }
      const latestOpenKey = openKeys[openKeys.length - 1]
      this.openKeys = [latestOpenKey]
    },
  },

});
</script>

<template>
  <div>
    <a-menu
        v-model:selectedKeys="this.selectedKeys"
        mode="inline"
        theme="dark"
        :open-keys="this.openKeys"
        @openChange="this.onOpenChange"
    >

      <a-sub-menu key="sub1">
        <template #icon>
          <MailOutlined />
        </template>
        <template #title>首页</template>
        <a-menu-item key="1">
          <router-link to="/">
            监控大厅
          </router-link>
        </a-menu-item>
      </a-sub-menu>

      <a-sub-menu key="sub2">
        <template #icon>
          <AppstoreOutlined />
        </template>
        <template #title>Navigation Two</template>
        <a-menu-item key="5">
          <router-link to="/sys/index">
            Option 5
          </router-link>
        </a-menu-item>
        <a-menu-item key="6">
          <router-link to="/sys/index">
            Option 6
          </router-link>
        </a-menu-item>
      </a-sub-menu>

      <a-sub-menu key="sub3">
        <template #icon>
          <SettingOutlined />
        </template>
        <template #title>Navigation Three</template>
        <a-menu-item key="9">
          <router-link to="/sys/index">
            Option 9
          </router-link>
        </a-menu-item>
        <a-menu-item key="10">
          <router-link to="/sys/index">
            Option 10
          </router-link>
        </a-menu-item>
      </a-sub-menu>

    </a-menu>
  </div>
</template>


<style>

</style>