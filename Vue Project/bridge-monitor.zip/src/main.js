import { createApp } from 'vue'
import App from './App.vue'
import router from "./router"
import DataVVue3 from '@kjgl77/datav-vue3'
import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css'
import dayjs from "dayjs"
// import Api from './api/AxiosConfig';
import axios from "axios"
// 适配flex
import '@/common/flexible.js';

// 引入全局css
import './assets/scss/style.scss';




const app = createApp(App)
app.use(router)
app.use(DataVVue3)
app.use(Antd)
app.config.globalProperties.$dayjs = dayjs;
// app.config.globalProperties.$api = Api;

// 前端请求默认发送到 http://localhost:9992
axios.defaults.baseURL = 'http://localhost:9992'
// 全局注册，之后可在其他组件中通过 this.$axios 发送数据
app.config.globalProperties.$axios = axios;
app.config.productionTip = true

app.mount('#app')