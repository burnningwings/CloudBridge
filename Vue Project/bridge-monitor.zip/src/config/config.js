// 桥梁ID -> 桥梁图片位置(/public/xxx.png)
let bridge_imgurl_mapping = {
    3: "/liugang.png",
    25: "/fuwan.png",
    29: "/xijiang.png",
    97: "/huangpu.png",
    98: "/yuejiang.png",

}
export const BRIDGE_IMGURL_MAPPING = bridge_imgurl_mapping;

// 传感器类型ID -> 传感器类型
let sensor_type_mapping = {
    1: "振弦传感器",
    2: "光纤应变传感器",
    3: "GPS传感器",
    4: "加速度传感器",
    5: "索力传感器",
}
export const SENSOR_TYPE_MAPPING = sensor_type_mapping;

let b = 1;
export const B = b;