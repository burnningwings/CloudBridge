<script>
import moment from 'moment';


export default {
  components: {
  },
  props:{
    component_parent: String
  },
  data() {
    return {
      timeStr: "",
    };
  },
  methods: {
    getCurrentTime(){
      this.timeStr =  moment().format("YYYY年MM月DD日 HH:mm:ss")
    }
  },
  created() {
  },
  mounted() {
    this.getCurrentTime()
    this.interval_time = setInterval(()=>this.getCurrentTime(), 1000)
  },
  beforeMount() {
    clearInterval(this.interval_time)
  }

}
</script>

<template>
<!-- Header第一行 -->
<div class="d-flex jc-center">
  <dv-decoration-10 style="width:33.3%;height:.0625rem;" />
  <div class="d-flex jc-center">
    <dv-decoration-8 :color="['#568aea', '#000000']" style="width:2.5rem;height:.325rem;" />
    <div class="title">
      <span v-if="component_parent==='MonitoringHall'" class="title-text">桥梁健康监控大厅</span>
      <span v-else class="title-text">桥梁健康管理系统</span>
      <dv-decoration-6
          class="title-bototm"
          :reverse="true"
          :color="['#50e3c2', '#67a1e5']"
          style="width:3.125rem;height:0.4rem;padding-top: 0.15rem"
      />
    </div>
    <dv-decoration-8
        :reverse="true"
        :color="['#568aea', '#000000']"
        style="width:2.5rem;height:.325rem;"
    />
  </div>
  <dv-decoration-10 style="width:33.3%;height:.0625rem; transform: rotateY(180deg);" />
</div>


<!-- Header第二行 -->
<div class="d-flex jc-between px-2" style="padding-left: 0;padding-right: 0">
  <div class="d-flex" style="width: 40%">
    <div
        class="react-right ml-4"
        style="width: 6.25rem; text-align: left;background-color: #0f1325;"
    >
      <span class="react-before"></span>
      <span class="text"><router-link to="http://localhost:9992/index" style="color:#33cea0 !important;">@进入系统</router-link></span>
    </div>
    <div class="react-right ml-3" style="background-color: #0f1325;">
<!--      <span class="text">TEXT2</span>-->
    </div>
  </div>
  <div style="width: 40%" class="d-flex">
    <div class="react-left bg-color-blue mr-3" style="background-color: #0f1325;">
<!--      <span class="text fw-b">TEXT3</span>-->
    </div>
    <div
        class="react-left mr-4"
        style="width: 6.25rem; background-color: #0f1325; text-align: right;"
    >
      <span class="react-after"></span>
      <span class="text">{{this.timeStr}}</span>
    </div>
  </div>
</div>
</template>




<style lang="scss" scoped>
@import "../../../assets/scss/index.scss";
</style>