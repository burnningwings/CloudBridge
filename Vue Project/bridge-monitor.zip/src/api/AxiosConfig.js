import axios from 'axios';
import store from 'storejs';
/** usage
*      this.$api.post('/test', {
       }, null, response => {
         if (response.status >= 200 && response.status < 300) {
           console.log(response.data);//请求成功，response为成功信息参数
         } else {
          console.log(response.message);//请求失败，response为失败信息
         }
       });
 * **/
let http = axios.create({
    baseURL: "http://localhost:8080/", //后台服务地址
    withCredentials: true,
    headers: {

    },
    transformRequest: [function (data,headers) {
        if (headers['Content-type'] === 'multipart/form-data') {
            return data;
        } else {
            return JSON.stringify(data);
        }
        // let newData = '';
        // for (let k in data) {
        //   if (data.hasOwnProperty(k) === true) {
        //     newData += encodeURIComponent(k) + '=' + encodeURIComponent(data[k]) + '&';
        //   }
        // }
        // return newData;
    }]
});

function apiAxios(method, url, params, token, response) {
    http({
        method: method,
        url: url,
        headers:{
            'Content-Type': 'application/json;charset=utf-8',
            'token': token
        },
        data: method === 'POST' || method === 'PUT' ? params : null,
        params: method === 'GET' || method === 'DELETE' ? params : null,
    }).then(function (res) {
        response(res);
    }).catch(function (err) {
        response(err);
    })
}

export default {
    get: function (url, params, token, response) {
        return apiAxios('GET', url, params, token, response)
    },
    post: function (url, params, token, response) {
        return apiAxios('POST', url, params, token, response)
    },
    put: function (url, params, token, response) {
        return apiAxios('PUT', url, params, token, response)
    },
    delete: function (url, params, token, response) {
        return apiAxios('DELETE', url, params, token, response)
    }
}