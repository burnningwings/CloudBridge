<script>
import Header from "./header/header.vue"
import Footer from "./footer/footer.vue"
import BridgeSelector from "../index/BridgeSelector.vue"
import MonitorGraph from "../index/MonitorGraph.vue"
import BridgeSensorClassification from "../index/BridgeSensorClassification.vue";
import ReliabilityAnalysis from "../index/ReliabilityAnalysis.vue"
import AssociationAnalysis from "../index/AssociationAnalysis.vue"
import axios from "axios";

export default {
  components:{
    MyHeader: Header,
    MyFooter: Footer,
    MyBridgeSelector: BridgeSelector,
    MyMonitorGraph: MonitorGraph,
    MyBridgeSensorClassification: BridgeSensorClassification,
    MyReliabilityAnalysis: ReliabilityAnalysis,
    MyAssociationAnalysis: AssociationAnalysis,
  },
  data() {
    return {
      loading: true,
      childMsg: [],   // MyBridgeSelector的桥梁选择参数
      msg2MonitorGraph: [],
      msg2ReliabilityAnalysis: [],
      msg2AssociationAnalysis: [],
    };
  },
  watch:{
    childMsg(newMsg, oldMsg){
      console.log("in father [MonitoringHall]: ", newMsg, oldMsg)
      if(newMsg[0]===0)
        this.msg2MonitorGraph = newMsg
      else if(newMsg[0]===1)
        this.msg2ReliabilityAnalysis = newMsg
      else if(newMsg[0]===2)
        this.msg2AssociationAnalysis = newMsg
      else
        console.log("wtf is going on")
    }
  },
  methods: {
    cancelLoading() {
      setTimeout(() => {
        this.loading = false;
      }, 1000);
    },
  },
  mounted() {
    this.cancelLoading();
    // this.getBridgeMessage()
  },
}
</script>

<template>
  <div id="index">
    <!--  position: fixed 时就不会有滚动条, static有滚动条
          height: 15rem -> 刚好一个屏幕
    -->
    <dv-full-screen-container class="bg" style="height:26.5rem;position: static;">
      <dv-loading v-if="loading">Loading...</dv-loading>
      <div v-else class="host-body">

        <!-- Header -->
        <MyHeader :component_parent="'MonitoringHall'"/>

        <!--  content      -->
        <a-layout class="rm-bg-color">
          <a-layout-content>
            <div>
              <!--       正文第一行       -->
              <a-row style="margin-top: 0.1rem;">

                <!-- 最左边的框 -->
                <a-col :span="6" style="height: 12.3rem">
                  <dv-border-box-12>
                    <div class="component-bg">

                      <MyBridgeSelector @response="(msg) => this.childMsg=msg"/>

                    </div>
                  </dv-border-box-12>
                </a-col>

                <!-- 中间的框 -->
                <a-col :span="12" style="height: 12.3rem">
                  <dv-border-box-12>
                    <div class="component-bg">

                      <MyMonitorGraph :msg="this.msg2MonitorGraph"/>

                    </div>

                  </dv-border-box-12>
                </a-col>

                <!-- 最右边的框 -->
                <a-col :span="6" style="height: 12.3rem">
                  <dv-border-box-12>
                    <div class="component-bg">

                      <MyBridgeSensorClassification/>

                    </div>
                  </dv-border-box-12>
                </a-col>
              </a-row>


              <!--       正文第二行       -->
              <a-row style="margin-top: 0.1rem;">
                <a-col :span="24" style="height: 6.1rem">
                  <dv-border-box-12>
                    <div class="component-bg">
                      <MyReliabilityAnalysis :msg="this.msg2ReliabilityAnalysis"/>
                    </div>
                  </dv-border-box-12>
                </a-col>
              </a-row>


              <!--       正文第三行       -->
              <a-row style="margin-top: 0.1rem;">
                <a-col :span="24" style="height: 6.1rem">
                  <dv-border-box-12>
                    <div class="component-bg">
                      <MyAssociationAnalysis :msg="this.msg2AssociationAnalysis"/>
                    </div>
                  </dv-border-box-12>
                </a-col>
              </a-row>

            </div>
          </a-layout-content>
        </a-layout>

        <!--   footer     -->
        <MyFooter/>

      </div>
    </dv-full-screen-container>
  </div>
</template>

<style lang="scss">
@import "../../assets/scss/index.scss";
.component-bg{
  text-align: center;
  // 控制在框內填充背景顏色的區域
  background-color: rgba(50, 52, 65, 0.6);
  width: 100%;
  height: 100%;
  padding: 10px;
  background-clip: content-box; // 去除padding和border部分的背景颜色

}
.rm-bg-color{
  background-color:transparent !important; // 除去antd组件样式的背景颜色
}

::v-deep .ant-card{
  background: #1c2031 !important;
  color: white !important;
}
</style>

