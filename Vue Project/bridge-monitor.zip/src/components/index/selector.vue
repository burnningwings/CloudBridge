<script>
export default {
  components: {

  },
  data(){
    return {
      options_bridge: [],
      options_section: [],
      options_point: [],
      options_box: [],
      options_sensor: [],
      selected_bridge: "选择桥梁",
      selected_section: "选择截面",
      selected_point: "选择测点",
      selected_box: "选择控制箱",
      selected_sensor: [],  // 选择传感器, 允许多选, 需要用列表保存
      current_bridgeID_map: {},   // name到id的映射
      current_sectionID_map: {},   // name到id的映射
      current_pointID_map: {},   // name到id的映射
      current_boxID_map: {},   // name到id的映射
      current_sensorID_map: {},   // name到id、sensor_type_name、sensor_type_id的映射
      loading: false,
      button_key: 0
    }
  },
  methods: {
    processInfo(info, type) {
      /**
       * 处理后端返回桥梁、截面、控制箱、监测点数据, 更新响应式对象数据
       * 名字和id需要一一对应，即不可同名，否则无法区分
       * **/
      if (type!=="bridge" && type!=="section" && type!=="watch_box" && type!=="watch_point"){
        alert("can't accept this type: " + type)
        return
      }
      info = info["data"]
      let name_key = type + "_name"
      let id_key = type + "_id"
      let options_arr = []
      let id_dict = {}
      for (let i=0;i<info.length;i++){
        let name = info[i][name_key]
        let id =  info[i][id_key]
        let option = {value: name, label: name}
        id_dict[name] = id
        options_arr.push(option)
      }
      if (type === "bridge"){
        this.options_bridge = options_arr
        this.current_bridgeID_map = id_dict
      }
      else if (type === "section"){
        this.options_section = options_arr
        this.current_sectionID_map = id_dict
      }
      else if (type === "watch_box"){
        this.options_box = options_arr
        this.current_boxID_map = id_dict
      }
      else {
        this.options_point = options_arr
        this.current_pointID_map = id_dict
      }
    },

    processSensorInfo(info){
      /** 处理后端传感器接口返回的数据, 更新响应式数据 **/
      info = info["data"]
      let options_arr = []
      let id_dict = {}
      for (let i=0;i<info.length;i++){
        let sensor_name = info[i]["sensor_name"]
        let sensor_id =  info[i]["sensor_id"]
        let sensor_type_name = info[i]["senor_type_name"]
        let sensor_type_id = info[i]["senor_type_id"]
        let option = {value: sensor_name, label: sensor_name}
        id_dict[name] = {"sensor_id": sensor_id, "sensor_type_name": sensor_type_name, "sensor_type_id": sensor_type_id}
        options_arr.push(option)
      }
      this.options_sensor = options_arr
      this.current_sensorID_map = id_dict
    },

    handleChangeBridge(){
      console.log("Bridge changed to: " + this.selected_bridge)
      // 重置所有其他选项数据
      this.selected_section = "选择截面"
      this.options_section = []
      this.current_sectionID_map = {}
      this.selected_point = "选择测点"
      this.options_point = []
      this.current_pointID_map = {}
      this.selected_box = "选择控制箱"
      this.options_box = []
      this.current_boxID_map = {}
      this.selected_sensor = []
      this.options_sensor = []
      this.current_sensorID_map = {}

      // TODO:根据bridge_id请求得到截面、控制箱的数据
      // section/simple-list?bridgeId={x}
      // watch-box/simple-list?bridgeId={x}
      let current_bridge_id = this.current_bridgeID_map[this.selected_bridge]
      let section_info = null
      if (current_bridge_id === 1)
        section_info = {"data":[{"section_id":1,"section_name":"截面1"},{"section_id":11,"section_name":"截面11"}]}
      else if (current_bridge_id === 2)
        section_info = {"data":[{"section_id":2,"section_name":"截面2"},{"section_id":22,"section_name":"截面22"}]}
      else if (current_bridge_id === 3)
        section_info = {"data":[{"section_id":3,"section_name":"截面3"},{"section_id":33,"section_name":"截面33"}]}

      if (section_info != null)
        this.processInfo(section_info, "section")


      let box_info = null
      if (current_bridge_id === 1)
        box_info = {"data":[{"watch_box_name":"控制箱1","watch_box_id":1},{"watch_box_name":"控制箱11","watch_box_id":11}]}
      else if (current_bridge_id === 2)
        box_info = {"data":[{"watch_box_name":"控制箱2","watch_box_id":2},{"watch_box_name":"控制箱22","watch_box_id":22}]}
      else if (current_bridge_id === 3)
        box_info = {"data":[{"watch_box_name":"控制箱3","watch_box_id":3},{"watch_box_name":"控制箱33","watch_box_id":33}]}

      if (box_info != null)
        this.processInfo(box_info, "watch_box")
    },

    handleChangeSection() {
      console.log("Section changed to: " + this.selected_section)
      // 重置测点和传感器数据
      this.selected_point = "选择测点"
      this.options_point = []
      this.current_pointID_map = {}
      this.selected_sensor = []
      this.options_sensor = []
      this.current_sensorID_map = {}
      // 控制箱和(截面、测点)这两个不能一起选
      this.selected_box = "选择控制箱"

      // TODO:根据section id请求得到监测点的数据
      // watch-point/simple-list?sectionId={x}
      let current_section_id = this.current_sectionID_map[this.selected_section]
      let point_info = null
      if (current_section_id === 1)
        point_info = {"data":[{"watch_point_name":"监测点1","watch_point_id":1},{"watch_point_name":"监测点11","watch_point_id":11}]}
      else if (current_section_id === 22)
        point_info = {"data":[{"watch_point_name":"监测点22","watch_point_id":22},{"watch_point_name":"监测点222","watch_point_id":222}]}
      else if (current_section_id === 3)
        point_info = {"data":[{"watch_point_name":"监测点3","watch_point_id":3},{"watch_point_name":"监测点33","watch_point_id":33}]}

      if (point_info != null)
        this.processInfo(point_info, "watch_point")
    },

    handleChangePoint() {
      console.log("Watch Point changed to: " + this.selected_point)
      // 重置传感器数据
      this.selected_sensor = []
      this.options_sensor = []
      this.current_sensorID_map = {}

      // TODO:根据watch point id请求得到传感器数据
      let current_point_id = this.current_pointID_map[this.selected_point]
      let sensor_info = null
      if (current_point_id === 1)
        sensor_info = {"total":1,"data":[{"sensor_number":"J001","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":150,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":4,"bridge_id":0,"sensor_type_name":"加速度传感器","sensor_name":"加速度point"},]}
      else if (current_point_id === 22)
        sensor_info = {"total":1,"data":[{"sensor_number":"A001","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":160,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":1,"bridge_id":0,"sensor_type_name":"振弦传感器","sensor_name":"正弦1point"},]}
      else if (current_point_id === 3)
        sensor_info = {"total":1,"data":[{"sensor_number":"J003","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":180,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":5,"bridge_id":0,"sensor_type_name":"索力传感器","sensor_name":"索力point"},]}

      if (sensor_info != null)
        this.processSensorInfo(sensor_info)
    },

    handleChangeBox(){
      console.log("Watch Box changed to: " + this.selected_box)
      // 重置传感器数据
      this.selected_sensor = []
      this.options_sensor = []
      this.current_sensorID_map = {}
      // 控制箱和(截面、测点)这两个不能一起选
      this.selected_section = "选择截面"
      this.selected_point = "选择测点"

      // TODO: 根据watch box id请求得到传感器数据
      // sensor/list?page=1&pageSize=9223372036854770&bridgeId={a}&sectionId={b}&watchPointId={c}&watchBoxId={d}
      let current_box_id = this.current_boxID_map[this.selected_box]
      let sensor_info = null
      if (current_box_id === 1)
        sensor_info = {"total":2,"data":[{"sensor_number":"J001","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":15,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":4,"bridge_id":0,"sensor_type_name":"加速度传感器","sensor_name":"加速度box"},
            {"sensor_number":"J0012","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":152,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":4,"bridge_id":0,"sensor_type_name":"加速度传感器","sensor_name":"加速度box-2"},
            {"sensor_number":"J0013","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
              "watch_box_id":0,"sensor_position":"xxx","sensor_id":153,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
              "sensor_type_id":4,"bridge_id":0,"sensor_type_name":"加速度传感器","sensor_name":"加速度box-3"}]}
      else if (current_box_id === 2)
        sensor_info = {"total":1,"data":[{"sensor_number":"A001","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":16,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":1,"bridge_id":0,"sensor_type_name":"振弦传感器","sensor_name":"正弦1box"},]}
      else if (current_box_id === 3)
        sensor_info = {"total":1,"data":[{"sensor_number":"J003","section_name":"xxx","watch_box_name":"xxx","watch_point_id":0,
            "watch_box_id":0,"sensor_position":"xxx","sensor_id":18,"bridge_name":"xxx","section_id":0,"watch_point_name":"xxx",
            "sensor_type_id":5,"bridge_id":0,"sensor_type_name":"索力传感器","sensor_name":"索力box"},]}

      if (sensor_info != null)
        this.processSensorInfo(sensor_info)
    },

    handleChangeSensor() {
      console.log("Sensor changed to: " + this.selected_sensor)
    },

    mySleep(time) {
      /** Usage
        this.mySleep(5000).then(()=>{
        console.log("睡完了")
        })**/
      return new Promise((resolve) => setTimeout(resolve, time));
    },

    sleep(n) {
      const start = new Date().getTime();
      //  console.log('休眠前：' + start);
      while (true) {
        if (new Date().getTime() - start > n) {
          break;
        }
      }
      // console.log('休眠后：' + new Date().getTime());
    },

    getSensorData(type_id){
      if (type_id === 1){
        // 振弦
      }
      else if (type_id === 2){
        // 光纤
      }
      else if (type_id === 3){
        // GPS
      }
      else if (type_id === 4){
        // 加速度
      }
      else{
        // 索力
      }
    },

    handleButtonClick() {
      console.log("Click the button")

    }
  },
  created() {
    console.log("created")
    // TODO:请求所有桥梁的数据
    //  bridge/simple-list
    let bridge_info = {"data":[{"bridge_name":"桥1","bridge_id":1},{"bridge_name":"桥2","bridge_id":2},{"bridge_name":"桥3","bridge_id":3}]}
    this.processInfo(bridge_info, "bridge")
    console.log("options_bridge: ")
    console.log(this.options_bridge)
    console.log("bridge_id: ")
    console.log(this.current_bridgeID_map)
  },
  mounted() {
    console.log("mounted")
  }

}
</script>

<template>
  <div class="selector-div">
    <a-space>
      <a-select
          ref="bridge_selector"
          v-model:value="selected_bridge"
          style="width: 120px;"
          :options="options_bridge"
          @change="handleChangeBridge"
      ></a-select>
      <a-select
          v-model:value="selected_section"
          style="width: 120px"
          :options="options_section"
          @change="handleChangeSection"
      ></a-select>
      <a-select
          v-model:value="selected_point"
          style="width: 120px"
          :options="options_point"
          @change="handleChangePoint"
      ></a-select>
      <a-select
          v-model:value="selected_box"
          style="width: 120px"
          :options="options_box"
          @change="handleChangeBox"
      ></a-select>
      <a-select
          v-model:value="selected_sensor"
          style="width: 500px"
          mode="multiple"
          placeholder="请选择传感器"
          :options="options_sensor"
          @change="handleChangeSensor"
      ></a-select>
      <a-button type="primary" :loading="this.loading" @click="handleButtonClick">{{this.loading? "加载中":"确定"}}</a-button>
    </a-space>
  </div>
</template>


<style lang="scss" scoped>
::v-deep .ant-select .ant-select-selector{
  background-color: #1c2031 !important;
  color: white !important;
}
::v-deep .ant-select-arrow{
  color: white !important;
}
::v-deep .ant-select-multiple .ant-select-selection-item{
  background-color: #1c2031 !important;
}
::v-deep .ant-select-multiple .ant-select-selection-item-remove{
  color: white !important;
}
.selector-div{
  padding: 0.2rem 0.15rem 0 0.15rem;   // top right bottom left
}
</style>








