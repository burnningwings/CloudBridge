import {createRouter, createWebHashHistory, createWebHistory} from 'vue-router'

const routes = [
    {
        // 监控大厅页面
        path: '/',
        name: 'default',
        component: () => import('../components/layout/MonitoringHall.vue')
    },
    {
        // 后台管理系统首页
        path: '/sys',
        name: 'index',
        component: () => import('../components/layout/DefaultLayout.vue'),
        children: [
            {
                // exact path: /sys/index
                path: 'index',
                name: 'index',
                component: () => import('../components/index/monitor-index.vue')
            },
        ]
    },
]


const router = createRouter({
    // history: createWebHashHistory(), //  hash 模式, url带#
    history: createWebHistory(),    // history模式
    routes: routes, //  或者缩写成routes
})

export default router