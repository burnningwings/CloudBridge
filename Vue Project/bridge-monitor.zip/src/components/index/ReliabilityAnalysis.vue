<script>
import * as echarts from 'echarts';
import moment from "moment";
import axios from "axios";

// let res = {
//   "msg":"",
//   "code":"00",
//   "data":{"timeList":["20220429075800","20220429080800","20220429081800","20220429082800","20220429083800","20220429084800","20220429085800","20220429090800","20220429091800","20220429092800","20220429093800","20220429094800"],
//     "mvp":[8.1E-44,8.4E-44,8.5E-44,9.1E-44,9.5E-44,9.5E-44,1.0E-43,1.11E-43,1.15E-43,1.19E-43,1.33E-43,1.39E-43],
//     "mvb":[13.831777,13.830184,13.828932,13.823812,13.820967,13.820967,13.818122,13.810156,13.80788,13.805036,13.7970705,13.794226],
//     "pvp":[1.04E-43,9.2E-44,9.0E-44,8.8E-44,8.8E-44,9.0E-44,9.0E-44,9.1E-44,9.4E-44,9.5E-44,9.8E-44,1.01E-43],
//     "pvb":[13.814617,13.8233,13.825728,13.8266535,13.826159,13.8253355,13.824758,13.823939,13.822301,13.820733,13.819152,13.81702]},
//   "status":0
// }


export default {
  props: {
    msg: {
      // [index, bridge_id, section_id, box_id, sensor_info, begin_time, end_time]
      // index：决定消息发送给哪个组件
      // sensor_info: {sensor_id: xxx, sensor_type_name: xxx, sensor_type_id: xxx}
      type: Array
    }
  },
  watch:{
    msg(newMsg, oldMsg){
      console.log("in child [ReliabilityAnalysis]: ", newMsg, oldMsg)
      this.doReliabilityAnalysis()
      // this.processReliabilityAnalysisMessage(res)
    }
  },
  data(){
    return {
      timeList: [],
      mvp: [],  // 监测失效概率
      pvp: [],  // 时变失效概率
      mvb: [],  // 监测可靠度
      pvb: [],  // 时变可靠度
      maxMvpOrPvp: 0,
      minMvpOrPvp: 0,
      maxMvbOrPvb: 0,
      minMvbOrPvb: 0,

    }
  },
  methods:{
    doReliabilityAnalysis(){
      let begin_time = moment(this.msg[5], "YYYY-MM-DD HH:mm:ss").format("YYYYMMDDHHmmss")
      let end_time = moment(this.msg[6], "YYYY-MM-DD HH:mm:ss").format("YYYYMMDDHHmmss")
      let params = {
        sensor_id: this.msg[4]["sensor_id"],
        begintime: begin_time,
        endtime: end_time,
      }
      axios.get("/reliability-analysis/start-analysis-spy-get", {params: params})
          .then(res => {
            console.log("axios got results from /reliability-analysis/start-analysis-spy-get in [ReliabilityAnalysis]: ", res)
            if(res["status"]===200 && res != null){
              if(res["data"]["data"]["result"]==="success"){
                this.getReliabilityAnalysisMessage(params)
              }
              else {
                alert("可靠性分析失败")
              }
            }
          }).catch(err =>{
        console.log("error: ", err)
      })

    },

    getReliabilityAnalysisMessage(params){
      axios.get("/reliability-analysis/getAnalysisResult-spy", {params: params})
          .then(res => {
            console.log("axios got results from /reliability-analysis/getAnalysisResult-spy in [ReliabilityAnalysis]: ", res)
            if(res["status"]===200 && res != null){
              this.processReliabilityAnalysisMessage(res)
            }
          }).catch(err =>{
        console.log("error: ", err)
      })
    },

    processReliabilityAnalysisMessage(res){
      res = res["data"]["data"]
      this.timeList = res["timeList"].map(item => {
        return moment(item, "YYYYMMDDHHmmss").format("YYYY-MM-DD HH:mm:ss")
      })
      this.mvp = res["mvp"]
      this.pvp = res["pvp"]
      this.mvb = res["mvb"]
      this.pvb = res["pvb"]
      this.maxMvpOrPvp = Math.max(...this.mvp, ...this.pvp)
      this.minMvpOrPvp = 0 //Math.min(...this.mvp, ...this.pvp)
      this.maxMvbOrPvb = Math.max(...this.mvb, ...this.pvb)
      this.minMvbOrPvb = Math.min(...this.mvb, ...this.pvb)
      console.log("[ReliabilityAnalysis] timeList: ", this.timeList)
      console.log("[ReliabilityAnalysis] mvp: ", this.mvp)
      console.log("[ReliabilityAnalysis] pvp: ", this.pvp)
      console.log("[ReliabilityAnalysis] mvb: ", this.mvb)
      console.log("[ReliabilityAnalysis] pvb: ", this.pvb)
      this.$forceUpdate()
    }

  },
  mounted() {

  },
  updated() {
    let leftChart = echarts.init(document.getElementById('left'))
    leftChart.setOption({
      title: {
        text: '传感器对应位置的时变失效概率监测值与预测值',
        textStyle: {
          color: "white",
          // fontSize: 15,
          // fontStyle: 'normal',
          // fontWeight: 'normal',
        },
      },
      legend: {
        data: ['监测失效概率', '时变失效概率'],
        // orient: 'vertical',
        x:'right',  //left, center, right
        y:'top',    //bottom, center, top
        textStyle:{
          color: "white",
        },
      },
      xAxis: {
        type: 'category',
        data: this.timeList,
        axisLabel: {
          textStyle: {
            color: "white",
          },
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '监测失效概率',
          min: this.minMvpOrPvp,
          max: this.maxMvpOrPvp,
          nameTextStyle: {
            color: 'white'
          },
          axisLabel: {
            textStyle:{
              color: "white",
            },
            formatter: function (value){  // formatter: '{value}'不会自动转换成科学计数法
              return value
            }
          }
        },
        {
          type: 'value',
          name: '时变失效概率',
          min: this.minMvpOrPvp,
          max: this.maxMvpOrPvp,
          nameTextStyle: {
            color: 'white'
          },
          axisLabel: {
            textStyle:{
              color: "white",
            },
            formatter: function (value){  // formatter: '{value}'不会自动转换成科学计数法
              return value
            },
          }
        },
      ],
      toolbox: {  // 工具栏
        orient: 'vertical',
        bottom: 2,
        iconStyle: {
          borderColor: "white",
        },
        // 工具栏的具体内容
        feature: {
          dataZoom: { yAxisIndex: false },
          // magicType: { show: true, type: ['line', 'bar'] },
          restore: { show: true },
          saveAsImage: { pixelRatio: 2 }
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        },
      },
      dataZoom: [ // 下方缩放条
        {type: 'inside'},
        {type: 'slider'}
      ],
      series: [
        {
          data: this.mvp,
          name: '监测失效概率',
          type: 'line',
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
        },
        {
          data: this.pvp,
          name: '时变失效概率',
          type: 'line',
          yAxisIndex: 1,
          tooltip: {
            valueFormatter: function (value) {
              return value;
            }
          },
        }
      ]
    }, true)

    let rightChart = echarts.init(document.getElementById('right'))
    rightChart.setOption({
      title: {
        text: '传感器对应位置的时变可靠指标监测值与预测值',
        textStyle: {
          color: "white",
        },
      },
      legend: {
        data: ['监测可靠度', '时变可靠度'],
        x:'right',  //left, center, right
        y:'top',    //bottom, center, top
        textStyle:{
          color: "white",
        },
      },
      xAxis: {
        type: 'category',
        data: this.timeList,
        axisLabel: {
          textStyle: {
            color: "white",
          },
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '监测可靠度',
          min: this.minMvbOrPvb,
          max: this.maxMvbOrPvb,
          nameTextStyle: {
            color: 'white'
          },
          axisLabel: {
            textStyle:{
              color: "white",
            },
            formatter: function (value){  // formatter: '{value}'不会自动转换成科学计数法
              return value
            },
          }
        },
        {
          type: 'value',
          name: '时变可靠度',
          min: this.minMvbOrPvb,
          max: this.maxMvbOrPvb,
          nameTextStyle: {
            color: 'white'
          },
          axisLabel: {
            textStyle:{
              color: "white",
            },
            formatter: function (value){  // formatter: '{value}'不会自动转换成科学计数法
              return value
            },
          }
        },
      ],
      toolbox: {  // 工具栏
        orient: 'vertical',
        bottom: 2,
        iconStyle: {
          borderColor: "white",
        },
        // 工具栏的具体内容
        feature: {
          dataZoom: { yAxisIndex: false },
          // magicType: { show: true, type: ['line', 'bar'] },
          restore: { show: true },
          saveAsImage: { pixelRatio: 2 }
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        },
      },
      dataZoom: [ // 下方缩放条
        {type: 'inside'},
        {type: 'slider'}
      ],
      series: [
        {
          data: this.mvb,
          name: '监测可靠度',
          type: 'line',
          tooltip: {
            valueFormatter: function (value) {  // formatter: '{value}'不会自动转换成科学计数法
              return value;
            }
          },
        },
        {
          data: this.pvb,
          name: '时变可靠度',
          type: 'line',
          yAxisIndex: 1,
          tooltip: {
            valueFormatter: function (value) {  // formatter: '{value}'不会自动转换成科学计数法
              return value;
            }
          },
        }
      ]
    }, true)
  },

}
</script>

<template>
<!--  <a-alert message="Success Text" type="success" />-->
  <a-row>
    <a-col :span="12">
      <dv-border-box8>
        <div id="left"  style="height: 5.85rem;">
        </div>
      </dv-border-box8>
    </a-col>

    <a-col :span="12">
      <dv-border-box8>
        <div id="right"  style="height: 5.85rem;">
        </div>
      </dv-border-box8>
    </a-col>
  </a-row>

</template>

<style scoped lang="scss">

</style>